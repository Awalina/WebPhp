<?php
$connection = mysql_connect("localhost","root","");
$db_name = "pondok_kelapa";
$select_the_db=mysql_select_db($db_name);
$url="http://localhost/pondok_kelapa/wp-admin/admin.php";
?>